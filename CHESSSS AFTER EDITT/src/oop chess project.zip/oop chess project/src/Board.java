import javax.swing.*;
import javax.swing.plaf.basic.BasicButtonUI;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.HashSet;
import java.util.Set;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.HashSet;
import java.util.Set;
public class Board implements ActionListener  {
     static Square[][] squares = new Square[8][8];
    int count =0;
    int intialrow;
    int intialcol;
    int finalrow;
    int finalcol;
     static Set<Pieces>  piecesBox = new HashSet<Pieces>();
public Board(){
  /*  int intialrow;
    int intialcol;
    int finalrow;
    int finalcol;*/
    //Set<Pieces> piecesBox = new HashSet<Pieces>();

//    Square[][] squares = new Square[8][8];
    JPanel panel2 = new JPanel(); //THIS PANEL HOLDS THE DIFFERENT PARTS OF THE MIDDLE PANEL

    JPanel panel2_1 = new JPanel(); //this is the TOP part of the middle panel
    JPanel panel2_2 = new JPanel(); //this is the LEFT part of the middle panel
    JPanel panel2_3 = new JPanel(); //this is the RIGHT part of the middle panel
    JPanel panel2_4 = new JPanel(); //this is the BOTTOM part of the middle panel
    JPanel panel2_5 = new JPanel(); //this is the MIDDLE part of the middle panel

   // int count =0;
    JFrame frame = new JFrame();


        frame.setSize(1390,780); //sets the x-dimension and the y-dimension of our frame
        frame.setLayout(null); //this is very important to be able to put the panels through the frame at the left,center,right
        frame.setResizable(false); //if we don't need the user to be able to change size of the window.

        // Get the screen dimensions
        GraphicsEnvironment ge = GraphicsEnvironment.getLocalGraphicsEnvironment();
        GraphicsDevice gd = ge.getDefaultScreenDevice();
        Rectangle screenBounds = gd.getDefaultConfiguration().getBounds();

        // Calculate the position of the frame
        int frameWidth = 1390;  // Adjust the frame width as needed
        int frameHeight = 780; // Adjust the frame height as needed

        //set the frame location on any PC window to be constant according to the size of its screen
        int x = (screenBounds.width - frameWidth) / 2;
        int y = (screenBounds.height - frameHeight) / 2;
        frame.setLocation(x, y);
        frame.setSize(frameWidth, frameHeight);


        //THE MIDDLE PANEL

        panel2.setBackground(Color.black); //sets background color of panel to be white
        panel2.setBounds(318, 0, 744, 744); //we set the bounds for panel 2 "the one in the middle"
        panel2.setLayout(new BorderLayout()); // we write this to make the border out of panels we made, from panel2_1 to panel2_5


        panel2_1.setBackground(Color.DARK_GRAY);
        panel2_2.setBackground(Color.DARK_GRAY);
        panel2_3.setBackground(Color.DARK_GRAY);
        panel2_4.setBackground(Color.DARK_GRAY);

        panel2_1.setPreferredSize(new Dimension(744, 22));
        panel2_2.setPreferredSize(new Dimension(22, 744));
        panel2_3.setPreferredSize(new Dimension(22, 744));
        panel2_4.setPreferredSize(new Dimension(744, 22));
        panel2_5.setPreferredSize(new Dimension(700, 700));



        for (int row=0; row<=7;row++){
            for (int col=0; col<=7; col++){
                squares[row][col] = new Square(row,col);
                int finalR = row;
                int finalC = col;
                squares[row][col].addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        count += 1;
                        if(count%2 !=0){

                            intialrow= squares[finalR][finalC].getRow();
                            intialcol=squares[finalR][finalC].getCol();
                         makeHighlihts(intialrow,intialcol);
                        }
                        else  {
                            finalrow= squares[finalR][finalC].getRow();
                            finalcol=squares[finalR][finalC].getCol();

                           System.out.println("row intial"+intialrow);
                            System.out.println("col int"+intialcol);
                            System.out.println("row final"+finalrow);
                            System.out.println("col final"+finalcol);
                            resetHighlights();
                            movePiece(intialrow,intialcol,finalrow,finalcol);
                        }
                    }
                });

                panel2_5.add (squares[row][col]);
            }
        }

        panel2_5.setLayout(new GridLayout(8, 8)); // We made this middle part to be the chess board consisting of 64 squares

        panel2.add(panel2_1, BorderLayout.NORTH);
        panel2.add(panel2_2, BorderLayout.WEST);
        panel2.add(panel2_3, BorderLayout.EAST);
        panel2.add(panel2_4, BorderLayout.SOUTH);
        panel2.add(panel2_5, BorderLayout.CENTER);

        squares[0][0].setPiece(new Rook(PieceType.Rook, ColorPiece.Black, 0, 0));
        squares[0][1].setPiece(new Knight(PieceType.Knight, ColorPiece.Black, 0, 1));
        squares[0][2].setPiece(new Bishop(PieceType.Bishop, ColorPiece.Black, 0, 2));
        squares[0][3].setPiece(new Queen(PieceType.Queen, ColorPiece.Black, 0, 3));
        squares[0][4].setPiece(new King(PieceType.King, ColorPiece.Black, 0, 4));
        squares[0][5].setPiece(new Bishop(PieceType.Bishop, ColorPiece.Black, 0, 5));
        squares[0][6].setPiece(new Knight(PieceType.Knight, ColorPiece.Black, 0, 6));
        squares[0][7].setPiece(new Rook(PieceType.Rook, ColorPiece.Black, 0, 7));

        for (int col = 0; col < 8; col++) {
            squares[1][col].setPiece(new Pawn(PieceType.Pawn, ColorPiece.Black, 1, col));
            squares[6][col].setPiece(new Pawn(PieceType.Pawn, ColorPiece.White, 6, col));
        }
        squares[7][0].setPiece(new Rook(PieceType.Rook, ColorPiece.White, 7, 0));
        squares[7][1].setPiece(new Knight(PieceType.Knight, ColorPiece.White, 7, 1));
        squares[7][2].setPiece(new Bishop(PieceType.Bishop, ColorPiece.White, 7, 2));
        squares[7][3].setPiece(new Queen(PieceType.Queen, ColorPiece.White, 7, 3));
        squares[7][4].setPiece(new King(PieceType.King, ColorPiece.White, 7, 4));
        squares[7][5].setPiece(new Bishop(PieceType.Bishop, ColorPiece.White, 7, 5));
        squares[7][6].setPiece(new Knight(PieceType.Knight, ColorPiece.White, 7, 6));
        squares[7][7].setPiece(new Rook(PieceType.Rook, ColorPiece.White, 7, 7));

        // set of updated piece.
        piecesBox.add(new Rook(PieceType.Rook, ColorPiece.White, 7, 0));
        piecesBox.add(new Rook(PieceType.Rook, ColorPiece.White, 7, 7));
        piecesBox.add(new Rook(PieceType.Rook, ColorPiece.Black, 0, 0));
        piecesBox.add(new Rook(PieceType.Rook, ColorPiece.Black, 0, 7));
        piecesBox.add(new Queen(PieceType.Queen, ColorPiece.White, 7, 3));
        piecesBox.add(new Queen(PieceType.Queen, ColorPiece.Black, 0, 3));
        piecesBox.add(new King(PieceType.King, ColorPiece.White, 7, 4));
        piecesBox.add(new King(PieceType.King, ColorPiece.Black, 0, 4));
        piecesBox.add(new Knight(PieceType.Knight, ColorPiece.White, 7, 1));
        piecesBox.add(new Knight(PieceType.Knight, ColorPiece.White, 7, 6));
        piecesBox.add(new Knight(PieceType.Knight, ColorPiece.Black, 0, 1));
        piecesBox.add(new Knight(PieceType.Knight, ColorPiece.Black, 0, 6));
        piecesBox.add(new Bishop(PieceType.Bishop, ColorPiece.White, 7, 2));
        piecesBox.add(new Bishop(PieceType.Bishop, ColorPiece.White, 7, 5));
        piecesBox.add(new Bishop(PieceType.Bishop, ColorPiece.Black, 0, 2));
        piecesBox.add(new Bishop(PieceType.Bishop, ColorPiece.Black, 0, 5));
        piecesBox.add(new Pawn(PieceType.Pawn, ColorPiece.White, 6, 0));
        piecesBox.add(new Pawn(PieceType.Pawn, ColorPiece.White, 6, 1));
        piecesBox.add(new Pawn(PieceType.Pawn, ColorPiece.White, 6, 2));
        piecesBox.add(new Pawn(PieceType.Pawn, ColorPiece.White, 6, 3));
        piecesBox.add(new Pawn(PieceType.Pawn, ColorPiece.White, 6, 4));
        piecesBox.add(new Pawn(PieceType.Pawn, ColorPiece.White, 6, 5));
        piecesBox.add(new Pawn(PieceType.Pawn, ColorPiece.White, 6, 6));
        piecesBox.add(new Pawn(PieceType.Pawn, ColorPiece.White, 6, 7));
        piecesBox.add(new Pawn(PieceType.Pawn, ColorPiece.Black, 1, 0));
        piecesBox.add(new Pawn(PieceType.Pawn, ColorPiece.Black, 1, 1));
        piecesBox.add(new Pawn(PieceType.Pawn, ColorPiece.Black, 1, 2));
        piecesBox.add(new Pawn(PieceType.Pawn, ColorPiece.Black, 1, 3));
        piecesBox.add(new Pawn(PieceType.Pawn, ColorPiece.Black, 1, 4));
        piecesBox.add(new Pawn(PieceType.Pawn, ColorPiece.Black, 1, 5));
        piecesBox.add(new Pawn(PieceType.Pawn, ColorPiece.Black, 1, 6));
        piecesBox.add(new Pawn(PieceType.Pawn, ColorPiece.Black, 1, 7));


        frame.add(panel2); // add panel 2 to the center of the frame
        frame.setVisible(true);
    }



    /*public boolean isLegalMove(int rowinitial, int colinitial, int rowfinal, int colfinal, String name,String colorpiece,String coloroccupied) {
        int row= Math.abs(rowinitial-rowfinal);
        int col=  Math.abs(colinitial-colfinal);

        if (colorpiece.equals(coloroccupied)) return false;

        else {

            switch(name) {
                case PieceType.Pawn
                        : {
                    return true;
                }

                case PieceType.Knight: {
                    return (row==2&& col==3)||(row==3&& col==2);
                }

                case PieceType.Bishop: {
                    return (row==3&&col==3)||(row==0&col==1);}

                case PieceType.Queen: {
                    boolean found= false;
                    //check horizontal moves to right
                    if((rowinitial==rowfinal)&& (colfinal>colinitial)) {
                        for(int i= colinitial+1;i<colfinal;i++) {
                            if(isSquareOccupied(rowfinal,i)!=null) found=true;
                            if(found)  return false;
                        }
                        return true;}
                    //check horizontal moves to left
                    else if((rowinitial==rowfinal)&& (colfinal<colinitial)) {
                        for(int i= colinitial-1;i>colfinal;i--) {
                            if(isSquareOccupied(rowfinal,i)!=null) found=true;
                            if(found)  return false;
                        }
                        return true;}

                    //check vertical moves to down
                    else if((colinitial==colfinal)&& (rowfinal>rowinitial)) {
                        for(int i= rowinitial+1;i<rowfinal;i++) {
                            if(isSquareOccupied(i, colfinal)!=null) found=true;
                            if(found)  return false;
                        }
                        return true;}
                    //check vertical moves to up
                    else if(colinitial==colfinal && rowfinal<rowinitial) {
                        for(int i= rowinitial-1;i>rowfinal;i--) {
                            if(isSquareOccupied(i, colfinal)!=null) found=true;
                            if(found)  return false;
                        }
                        return true;}

                    return (row==3&&col==3)||(row==0&col==1);
                }

                case "King": {

                    return true;}
                case "Rook" : {
                    boolean found= false;
                    //check horizontal moves to right
                    if((rowinitial==rowfinal)&& (colfinal>colinitial)) {
                        for(int i= colinitial+1;i<colfinal;i++) {
                            if(isSquareOccupied(rowfinal,i)!=null) found=true;
                            if(found)  return false;
                        }
                        return true;}
                    //check horizontal moves to left
                    else if((rowinitial==rowfinal)&& (colfinal<colinitial)) {
                        for(int i= colinitial-1;i>colfinal;i--) {
                            if(isSquareOccupied(rowfinal,i)!=null) found=true;
                            if(found)  return false;
                        }
                        return true;}

                    //check vertical moves to down
                    else if((colinitial==colfinal)&& (rowfinal>rowinitial)) {
                        for(int i= rowinitial+1;i<rowfinal;i++) {
                            if(isSquareOccupied(i, colfinal)!=null) found=true;
                            if(found)  return false;
                        }
                        return true;}
                    //check vertical moves to up
                    else if(colinitial==colfinal && rowfinal<rowinitial) {
                        for(int i= rowinitial-1;i>rowfinal;i--) {
                            if(isSquareOccupied(i, colfinal)!=null) found=true;
                            if(found)  return false;
                        }
                        return true;}

                }
            }
            return false;
        }

    }*/
    public void makeHighlihts(int fromRow,int fromCol){
      char  movingPieceType =Pieces.getId(fromRow,fromCol).charAt(1);
       char movingPieceColor=Pieces.getId(fromRow,fromCol).charAt(0);
       for(int i=0;i<8;i++){
           for (int j=0;j<8;j++){
       if(Pieces.isMoveValid(fromRow,fromCol,i,j)){
       switch (movingPieceType)
       {
           case 'P'->{
               if(Pawn.isMoveValid(fromRow,fromCol,i,j,movingPieceColor)){
                   squares[i][j].setBackground(Color.GREEN);
               }

           }
       }
    }}}}
    public void resetHighlights(){

        for (int i = 0; i <8; i++) {
            for (int j = 0; j < 8; j++) {
                if ((i + j) % 2 != 0) {     // checking for white and black squares in the chess board
                    squares[i][j].setBackground(new Color(139, 92, 9));

                } else {
                    squares[i][j].setBackground(new Color(250, 229, 192));
                }
                // Override the ButtonUI to make it non-clickable
                squares[i][j].setUI(new BasicButtonUI());

                //set the appearance of the button
                squares[i][j].setFocusPainted(false);
                squares[i][j].setBorderPainted(false);
                squares[i][j].setOpaque(true);
            }}}


    Pieces pieceAt(int row, int col) {
        for (Pieces loopSelect : piecesBox) {
            if (loopSelect.getCurrentRow() == row && loopSelect.getCurrentColumn() == col) {
                return loopSelect;}
        }
        return null;
    }

    // A method to move the piece
    char movingPieceType,movingPieceColor ,squareOccupiedType,colorOccupied;
    ColorPiece color;
    Pieces movingPiece,isSquareOccupied;
String str1,str2;
 public  void movePiece( int fromRow,int fromCol, int toRow, int toCol) {

     movingPiece=pieceAt(fromRow,fromCol);
  movingPieceType =Pieces.getId(fromRow,fromCol).charAt(1);
  System.out.println(Pieces.getId(fromRow,fromCol).charAt(1));
  movingPieceColor=Pieces.getId(fromRow,fromCol).charAt(0);
  squareOccupiedType=Pieces.getId(toRow,toCol).charAt(1);
     System.out.println(Pieces.getId(toRow,toCol).charAt(1));
     colorOccupied=Pieces.getId(toRow,toCol).charAt(0);
     System.out.println(Pieces.getId(toRow,toCol).charAt(0));
     isSquareOccupied=pieceAt(toRow,toCol);
     if( movingPieceColor=='W')
         color=ColorPiece.White;
     else
         color=ColorPiece.Black;

if(Pieces.isMoveValid(fromRow,fromCol,toRow,toCol)){
    System.out.println("PIECE VALID");
          switch (movingPieceType) {
               case 'P' -> {
                   System.out.println("IM PAWN");
                   if(Pawn.isMoveValid(fromRow,fromCol,toRow,toCol,movingPieceColor)){

                       System.out.println("PAWN VALID");
                   if (squareOccupiedType ==' ')
                   {
                       squares[toRow][toCol].setPiece(new Pawn(PieceType.Pawn,color, toRow, toCol));
                       squares[fromRow][fromCol].setIcon(null);
                       piecesBox.add(new Pawn(PieceType.Pawn,movingPiece.getColor(), toRow, toCol));
                       piecesBox.remove(movingPiece);
                       Pieces.id[fromRow][fromCol]=null;
                       System.out.println("PAWN VALID INSIDE OCCUI");
                       makPromotion(toRow,toCol,movingPiece);
                   } else {
                       piecesBox.remove(isSquareOccupied);
                       squares[toRow][toCol].setIcon(null);
                       squares[fromRow][fromCol].setIcon(null);
                       squares[toRow][toCol].setPiece(new Pawn(PieceType.Pawn,color, toRow, toCol));
                       piecesBox.add(new Pawn(PieceType.Pawn, color, toRow, toCol));
                       System.out.println(Pieces.getId(toRow,toCol).charAt(1));
                       piecesBox.remove(movingPiece);
                       Pieces.id[fromRow][fromCol]=null;
                       makPromotion(toRow,toCol,movingPiece);
                       System.out.println("PAWN VALID NOT IN OCCUI");
                   }
               }
           }
     //REMOVE WHEN ADD others
            case 'Q'-> {
             //   if(isLegalMove(fromRow, fromCol, toRow,toCol,PieceType.Queen, movingPiece.getColor(), colorOccupied( toRow, toCol))) {
                    if(squareOccupiedType ==' ') {
                        squares[toRow][toCol].setPiece(new Queen(PieceType.Queen, movingPiece.getColor(), toRow, toCol));
                        squares[fromRow][fromCol].setIcon(null);
                        piecesBox.add(new Queen(PieceType.Queen, movingPiece.getColor(), toRow, toCol));
                        piecesBox.remove(movingPiece);}
                    else {
                        piecesBox.remove(isSquareOccupied);
                        squares[toRow][toCol].setIcon(null);
                         squares[fromRow][fromCol].setIcon(null);
                        squares[toRow][toCol].setPiece(new Queen(PieceType.Queen, movingPiece.getColor(), toRow, toCol));
                        piecesBox.add(new Queen(PieceType.Queen, movingPiece.getColor(), toRow, toCol));
                        piecesBox.remove(movingPiece);
                    }
                }
            }}}
         /*   case "Knight" -> {

                if(isLegalMove(fromRow, fromCol, toRow,toCol,PieceType.Knight, movingPiece.getColor(), colorOccupied( toRow, toCol))) {
                    if(isSquareOccupied(toRow,toCol )==null) {
                        squares[toRow][toCol].setPiece(new Knight(PieceType.Knight, movingPiece.getColor(), toRow, toCol));
                        squares[fromRow][fromCol].setIcon(null);
                        piecesBox.add(new Knight(PieceType.Knight, movingPiece.getColor(), toRow, toCol));
                        piecesBox.remove(movingPiece);
                    }
                    else {
                        piecesBox.remove(isSquareOccupied(toRow, toCol));
                        squares[toRow][toCol].setIcon(null); squares[fromRow][fromCol].setIcon(null);
                        squares[toRow][toCol].setPiece(new Knight(PieceType.Knight, movingPiece.getColor(), toRow, toCol));
                        piecesBox.add(new Knight(PieceType.Knight, movingPiece.getColor(), toRow, toCol));
                        piecesBox.remove(movingPiece);
                    }
                }
            }
            case "King" -> {
                if(isSquareOccupied(toRow,toCol )==null) {
                    squares[toRow][toCol].setPiece(new King(PieceType.King, movingPiece.getColor(), toRow, toCol));
                    squares[fromRow][fromCol].setIcon(null);
                    piecesBox.add(new King(PieceType.King, movingPiece.getColor(), toRow, toCol));
                    piecesBox.remove(movingPiece);}
                else {
                    piecesBox.remove(isSquareOccupied(toRow, toCol));
                    squares[toRow][toCol].setIcon(null); squares[fromRow][fromCol].setIcon(null);
                    squares[toRow][toCol].setPiece(new King(PieceType.King, movingPiece.getColor(), toRow, toCol));
                    piecesBox.add(new King(PieceType.King, movingPiece.getColor(), toRow, toCol));
                    piecesBox.remove(movingPiece);}
            }
            case "Bishop" -> {
                if(isLegalMove(fromRow, fromCol, toRow,toCol,PieceType.Bishop, movingPiece.getColor(), colorOccupied( toRow, toCol))) {
                    if(isSquareOccupied(toRow,toCol )==null) {
                        squares[toRow][toCol].setPiece(new Bishop(PieceType.Bishop, movingPiece.getColor(), toRow, toCol));
                        squares[fromRow][fromCol].setIcon(null);
                        piecesBox.add(new Bishop(PieceType.Bishop, movingPiece.getColor(), toRow, toCol));
                        piecesBox.remove(movingPiece); }
                    else {
                        piecesBox.remove(isSquareOccupied(toRow, toCol));
                        squares[toRow][toCol].setIcon(null); squares[fromRow][fromCol].setIcon(null);
                        squares[toRow][toCol].setPiece(new Bishop(PieceType.Bishop, movingPiece.getColor(), toRow, toCol));
                        piecesBox.add(new Bishop(PieceType.Bishop, movingPiece.getColor(), toRow, toCol));
                        piecesBox.remove(movingPiece);}
                } }
            case "Rook" -> {
                if(isLegalMove(fromRow, fromCol, toRow,toCol,Rook, movingPiece.getColor(), colorOccupied( toRow, toCol) )) {
                    if(isSquareOccupied(toRow,toCol )==null) {
                        squares[toRow][toCol].setPiece(new Rook(Rook, movingPiece.getColor(), toRow, toCol));
                        squares[fromRow][fromCol].setIcon(null);
                        piecesBox.add(new Rook(Rook, movingPiece.getColor(), toRow, toCol));
                        piecesBox.remove(movingPiece);}
                    else {
                        piecesBox.remove(isSquareOccupied(toRow, toCol));
                        squares[toRow][toCol].setIcon(null); squares[fromRow][fromCol].setIcon(null);
                        squares[toRow][toCol].setPiece(new Rook(Rook, movingPiece.getColor(), toRow, toCol));
                        piecesBox.add(new Rook(Rook, movingPiece.getColor(), toRow, toCol));
                        piecesBox.remove(movingPiece);}
                }
            }*/

    public static void makPromotion(int toRow,int toCol,Pieces movingPiece){
        if (Pawn.willBePromoted(toRow)){

            JFrame frameP =new JFrame();
            frameP.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);//good for temporary window
            frameP.setSize(200,200);
            frameP.setResizable(false);
            ImageIcon icon=new ImageIcon("360_F_346775711_wgofOdl8Z4DKi0FR9mBFRo1FK3kmMtC9.jpg");
            frameP.setIconImage(icon.getImage());
            JLabel label=new JLabel();
            label.setText("Choose the piece to pe promoted to:");
            JPanel panel = new JPanel();
            JPanel buttonPanel = new JPanel();
            panel.add(label, BorderLayout.NORTH);
            buttonPanel.setLayout(new GridLayout(1, 4));
            JButton queenButton = new JButton("Queen");
            JButton rookButton = new JButton("Rook");
            JButton bishopButton = new JButton("Bishop");
            JButton knightButton = new JButton("Knight");
            queenButton.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    squares[toRow][toCol].setPiece(new Queen(PieceType.Queen, movingPiece.getColor(), toRow, toCol));
                    piecesBox.add(new Queen(PieceType.Queen, movingPiece.getColor(), toRow, toCol));
                    frameP.dispose();
                }
            });
            rookButton.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    squares[toRow][toCol].setPiece(new Rook(PieceType.Rook, movingPiece.getColor(), toRow, toCol));
                    piecesBox.add(new Rook(PieceType.Rook, movingPiece.getColor(), toRow, toCol));
                    frameP.dispose();
                }
            });
            bishopButton.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    squares[toRow][toCol].setPiece(new Bishop(PieceType.Bishop, movingPiece.getColor(), toRow, toCol));
                    piecesBox.add(new Bishop(PieceType.Bishop, movingPiece.getColor(), toRow, toCol));
                    frameP.dispose();
                }
            });
            knightButton.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    squares[toRow][toCol].setPiece(new Knight(PieceType.Knight, movingPiece.getColor(), toRow, toCol));
                    piecesBox.add(new Knight(PieceType.Knight, movingPiece.getColor(), toRow, toCol));
                    frameP.dispose();
                }
            });

            buttonPanel.add(queenButton);
            buttonPanel.add(rookButton);
            buttonPanel.add(bishopButton);
            buttonPanel.add(knightButton);
            panel.add(buttonPanel,BorderLayout.CENTER);
            frameP.add(panel);
            frameP.pack();
            frameP.setVisible(true);


        }
    }





    @Override
    public void actionPerformed(ActionEvent e) {

    }}








