import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Main {
    public static void main(String[] args) {
        Board Game=new Board();
      // Pieces mypiece=new Pieces(PieceType.Pawn,ColorPiece.Black,5,6);

/*for(int i=0;i<8;i++){
    for(int j=0;j<8;j++) {
System.out.println(Pieces.id[i][j]);

    }}*/




    }



}

