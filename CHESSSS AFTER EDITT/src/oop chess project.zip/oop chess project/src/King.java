public class King extends Pieces{
    public King( PieceType pieceType,ColorPiece color,int currentRow,int currentColumn) {
        super(pieceType,color,currentRow,currentColumn);
    }

  @Override
   public  String getPath(ColorPiece color) {
       return color==ColorPiece.White? "C:\\Users\\Shahd\\IdeaProjects\\oop chess project\\src\\WhiteKing.png" : "C:\\Users\\Shahd\\IdeaProjects\\oop chess project\\src\\BlackKing.png";
   }
}
