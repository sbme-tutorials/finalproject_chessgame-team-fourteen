public enum PieceType {
   Pawn,Knight,Bishop,Queen,King,Rook
}
