import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Pawn extends Pieces{
    public Pawn(){

    }
   private boolean canCapture=false;
   private boolean canBePromoted=false;
   private boolean isFirstMove=false;
   private int nump;
   private static int numOfMove=0;


public Pawn(PieceType pieceType,ColorPiece color,int currentColumn,int currentRow)
{
    super(pieceType,color,currentColumn,currentRow);
}


    static Button[][] squares = new Button[8][8];//need to be edited to take this value from buttons made in main frame of game
    public static boolean isFirstMove(int fromRow,char color){
      if((fromRow==1&&color=='B')||(fromRow==6&&color=='W'))
          return true;
      else
          return false;
    }

   public static boolean isMoveValid(int fromRow, int fromCol, int toRow, int toCol,char color) {
        switch (color){
            case 'B':
            {
                if (toRow-fromRow==1&&toCol-fromCol==0){

                    return true;//move forward
                }
                else if (toRow-fromRow==1&&Math.abs(toCol-fromCol)==1) //move diagonally if it will eat
                {
                    if (id[toRow][toCol]!=null)
                    {
                        return true;

                    }
                    else return false;

                }
                else if(isFirstMove(fromRow, color)&&toRow-fromRow==2&&toCol-fromCol==0){
                    return true;
                }
                else {

                    return false;

                }


            }
            case 'W':
            {
                if (toRow-fromRow==-1&&toCol-fromCol==0){

                    return true;//move forward
                }
                else if (toRow-fromRow==-1&&Math.abs(toCol-fromCol)==1) //move diagonally if it will eat
                {
                    if (id[toRow][toCol]!=null)
                    {
                        return true;

                    }
                    else return false;

                }
                else if(isFirstMove(fromRow, color)&&toRow-fromRow==-2&&toCol-fromCol==0){
                    return true;
                }
                else {

                    return false;

                }


            }





        }
        return false;
   }
public static boolean willBePromoted(int toRow){
if (toRow==7||toRow==0)
    return true;
else
    return false;
}
//IN THIS Method we need to add it to the board class to make replacement
public static void makPromotion(int toRow,int toCol,Pieces movingPiece){
        if (willBePromoted(toRow)){

            JFrame frameP =new JFrame();
            frameP.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);//good for temporary window
            frameP.setSize(200,200);
            frameP.setResizable(false);
            ImageIcon icon=new ImageIcon("360_F_346775711_wgofOdl8Z4DKi0FR9mBFRo1FK3kmMtC9.jpg");
            frameP.setIconImage(icon.getImage());
            JLabel label=new JLabel();
            label.setText("Choose the piece to pe promoted to:");
            JPanel panel = new JPanel();
            JPanel buttonPanel = new JPanel();
            panel.add(label, BorderLayout.NORTH);
            buttonPanel.setLayout(new GridLayout(1, 4));
            JButton queenButton = new JButton("Queen");
            JButton rookButton = new JButton("Rook");
            JButton bishopButton = new JButton("Bishop");
            JButton knightButton = new JButton("Knight");
        queenButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                 Board.piecesBox.add(new Queen(PieceType.Queen,movingPiece.getColor(), toRow, toCol));
                 ImageIcon icon=new ImageIcon("C:\\Users\\Shahd\\IdeaProjects\\oop chess project\\src\\BlackQueen.png");
                 icon.setImage(icon.getImage());
                frameP.dispose();
            }
        });
        rookButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                Board.piecesBox.add(new Rook(PieceType.Rook,movingPiece.getColor(), toRow, toCol));
                frameP.dispose();
            }
        });
        bishopButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
               Board.piecesBox.add(new Bishop(PieceType.Bishop,movingPiece.getColor(), toRow, toCol));
                frameP.dispose();
            }
        });
        knightButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
               Board.piecesBox.add(new Knight(PieceType.Knight,movingPiece.getColor(), toRow, toCol));
                frameP.dispose();
            }
        });

            buttonPanel.add(queenButton);
            buttonPanel.add(rookButton);
            buttonPanel.add(bishopButton);
            buttonPanel.add(knightButton);
            panel.add(buttonPanel,BorderLayout.CENTER);
            frameP.add(panel);
            frameP.pack();
            frameP.setVisible(true);


}
}


  /*  public static void calculateLegalMove(int fromRow,int fromCol,int toRow,int toCol,int color ) {
        if (isMoveValid(fromRow,fromCol,toRow,toCol)&&isFirstMove(fromRow,color)){
            Board.squares[fromRow+2][fromCol].setBackground(Color.GREEN);
            numOfMove++;
        }
        if (isMoveValid(fromRow,fromCol,toRow,toCol))
        {
            Board.squares[fromRow+1][fromCol].setBackground(Color.GREEN);
            Board.squares[fromRow+1][fromCol+1].setBackground(Color.GREEN);
            Board.squares[fromRow+1][fromCol-1].setBackground(Color.GREEN);

        }

    }*/
    @Override
    public String getPath(ColorPiece color) {
        return color==ColorPiece.White? "C:\\Users\\Shahd\\IdeaProjects\\oop chess project\\src\\WhitePawn.png" : "C:\\Users\\Shahd\\IdeaProjects\\oop chess project\\src\\BlackPawn.png";
    }



    }
