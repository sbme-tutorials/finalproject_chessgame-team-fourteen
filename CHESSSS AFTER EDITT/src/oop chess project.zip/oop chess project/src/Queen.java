public class Queen extends Pieces{
    public Queen( PieceType pieceType,ColorPiece color,int currentRow,int currentColumn) {
        super(pieceType,color,currentRow,currentColumn);
    }
    @Override
    public String getPath(ColorPiece color) {
        return color==ColorPiece.White? "C:\\Users\\Shahd\\IdeaProjects\\oop chess project\\src\\WhiteQueen.png" : "C:\\Users\\Shahd\\IdeaProjects\\oop chess project\\src\\BlackQueen.png";
    }


}
