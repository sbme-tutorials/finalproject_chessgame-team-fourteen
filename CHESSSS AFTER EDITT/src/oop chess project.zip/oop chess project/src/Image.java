/*public enum Image {
    "WhitePawn.png","WhiteBishop.png","WhiteRook.png","WhiteKing.png","WhiteQueen.png","WhiteKing.png","BlackPawn.png","BlackBishop.png","BlackRook.png","BlackKing.png","BlackQueen.png","BlackKnight.png"

}
*/