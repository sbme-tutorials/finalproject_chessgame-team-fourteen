public class Bishop extends Pieces{
    public Bishop( PieceType pieceType,ColorPiece color,int currentRow,int currentColumn) {
        super(pieceType,color,currentRow,currentColumn);
    }
    @Override
    public  String getPath(ColorPiece color) {
        return color==ColorPiece.White? "C:\\Users\\Shahd\\IdeaProjects\\oop chess project\\src\\WhiteBishop.png" : "C:\\Users\\Shahd\\IdeaProjects\\oop chess project\\src\\BlackBishop.png";
    }
}
