public class Rook  extends Pieces{
    public Rook( PieceType pieceType,ColorPiece color,int currentRow,int currentColumn) {
        super(pieceType,color,currentRow,currentColumn);
    }

    @Override
    public String getPath(ColorPiece color) {
        return color==ColorPiece.White? "C:\\Users\\Shahd\\IdeaProjects\\oop chess project\\src\\WhiteRook.png" : "C:\\Users\\Shahd\\IdeaProjects\\oop chess project\\src\\BlackRook.png";
    }
}
