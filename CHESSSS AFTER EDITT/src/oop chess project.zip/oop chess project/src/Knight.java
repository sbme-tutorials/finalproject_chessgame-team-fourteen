public class Knight extends Pieces{
    public Knight( PieceType pieceType,ColorPiece color,int currentRow,int currentColumn) {
        super(pieceType,color,currentRow,currentColumn);
    }
    @Override
    public String getPath(ColorPiece color) {
        return color==ColorPiece.White?  "C:\\Users\\Shahd\\IdeaProjects\\oop chess project\\src\\WhiteKnight.png" : "C:\\Users\\Shahd\\IdeaProjects\\oop chess project\\src\\BlackKnight.png";
    }
}
